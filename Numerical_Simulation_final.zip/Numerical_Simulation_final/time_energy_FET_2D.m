clear all;
clc;

% outer coupling matrices
B1 = [-3, 1.5, 1.5;
      1, -3, 2;
      3, 1, -4];

B2 = [0, 0, 0;
      0, -3, 3;
      1.5, 0.5, -2];

B3 = [-3.5, 1.5, 2;
      -0.5, 0.5, 0;
      0.5, 3.5, -4];

% inner coupling matrices
C1 = [9, 0, 0.3;
      0, 9, 0;
      0.3, 0, 8];

C2 = [7, 1, 0.2;
      1, -0.5, 0.2;
      0.2, 0.2, 6];

C3 = [9, 1, 0.2;
      1, 3, 0.2;
      0.2, 0.2, 2];

C = [4, 0.5, 0;
     0.5, 5, 1;
     0, 1, 6];


T = 2;
dt = 0.0001;
step = T / dt;
N = 3; % number of nodes
W = 3; % number of weights
dm = 3;% dimension
rho = 2.2;% coupling strength
q1 = 1;
a = 3/5;

p = 2;% norm
Cp = 6.645;% p-norm of matrix C

En=0;% true energy


z_axis = zeros(1, step);
for i = 2 : step
   z_axis(i) =  dt * (i - 1);
end

z0_1 = [1, 2, 3]';
z0_2 = [2, 3, 4]';
z0_3 = [3, 4, 5]';

zbar1 = zeros(dm, step);% first node
zbar2 = zeros(dm, step);% second node
zbar3 = zeros(dm, step);% third node
zbar1(:, 1) = z0_1;
zbar2(:, 1) = z0_2;
zbar3(:, 1) = z0_3;

% initial values
z0_0 = [1, 1, 1]';
zbar0 = zeros(dm, step);
zbar0(:, 1) = z0_0;

ebar = zeros(1, step);
ebar(1) = sqrt((z0_1 - z0_0)' * (z0_1 - z0_0) + (z0_2 - z0_0)' * (z0_2 - z0_0) + (z0_3 - z0_0)' * (z0_3 - z0_0));

% normalized left eigenvectors
ome1 = [0.2483, 0.4546, 0.2971];
ome2 = [0.2898, 0.4367, 0.2735];
ome3 = [0.4049, 0.2845, 0.3106];    
    
V0 = 1/2*(ome1(1)*(z0_1(1)-z0_0(1))^2+ome1(2)*(z0_1(2)-z0_0(2))^2+ome1(3)*(z0_1(3)-z0_0(3))^2 ...
     + ome2(1)*(z0_2(1)-z0_0(1))^2+ome2(2)*(z0_2(2)-z0_0(2))^2+ome2(3)*(z0_2(3)-z0_0(3))^2 ...
     + ome3(1)*(z0_3(1)-z0_0(1))^2+ome3(2)*(z0_3(2)-z0_0(2))^2+ome3(3)*(z0_3(3)-z0_0(3))^2);

alpha2 = (q1*2^((a+1)/2))/(0.2483^((a-1)/2));
T_est = 2*V0^((1-a)/2)/(alpha2*(1-a))% estimation for time

alpha3 = (2^(3*p/2)*rho^p*Cp^p*(N*dm)^(1-min(p,2)/2))/(alpha2*(p+1-a)*0.2483^(p/2));
alpha4 = (2^(a*p/2+p)*q1^p*(N*dm)^((max(p,2)-a*p)/2))/(alpha2*(a*p+1-a)*0.2483^(a*p/2));
En_est = alpha3*V0^((p+1-a)/2)+alpha4*V0^((a*p+1-a)/2)% estimation for energy


q1_step = 500;
q1_axis = 0:0.01:5;

delta = 0.1;% weights, delta and eta

TC = zeros(1, q1_step+1);
EC = zeros(1, q1_step+1);
Phi = zeros(1, q1_step+1);

for k = 1 : q1_step+1
    q1 = q1_axis(k);
    En = 0;
for i = 1 : (step - 1)
    tmp = zeros(dm, N);
    
    for j = 1 : N
        tmp(:, j) = rho * (B1(j, 1) * C1 * zbar1(:, i)...
                    + B1(j, 2) * C1 * zbar2(:, i) + B1(j, 3) * C1 * zbar3(:, i)...
                    + B2(j, 1) * C2 * zbar1(:, i) + B2(j, 2) * C2 * zbar2(:, i)...
                    + B2(j, 3) * C2 * zbar3(:, i) + B3(j, 1) * C3 * zbar1(:, i)...
                    + B3(j, 2) * C3 * zbar2(:, i) + B3(j, 3) * C3 * zbar3(:, i));
    end
    tmp(:, 1) = tmp(:, 1) - rho * C * (zbar1(:, i)-zbar0(:, i)) - q1 * (zbar1(:, i)-zbar0(:, i)).^a;
    tmp(:, 2) = tmp(:, 2) - rho * C * (zbar2(:, i)-zbar0(:, i)) - q1 * (zbar2(:, i)-zbar0(:, i)).^a;
    tmp(:, 3) = tmp(:, 3) - rho * C * (zbar3(:, i)-zbar0(:, i)) - q1 * (zbar3(:, i)-zbar0(:, i)).^a;
        
    zbar0(:, i + 1) = zbar0(:, i) + gx(zbar0(:, i)) * dt;
    zbar1(:, i + 1) = zbar1(:, i) + (gx(zbar1(:, i)) + tmp(:, 1)) * dt;
    zbar2(:, i + 1) = zbar2(:, i) + (gx(zbar2(:, i)) + tmp(:, 2)) * dt;
    zbar3(:, i + 1) = zbar3(:, i) + (gx(zbar3(:, i)) + tmp(:, 3)) * dt;
    ebar(i + 1) = sqrt((zbar1(:, i + 1) - zbar0(:, i + 1))' * (zbar1(:, i + 1) - zbar0(:, i + 1))...
                + (zbar2(:, i + 1) - zbar0(:, i + 1))' * (zbar2(:, i + 1) - zbar0(:, i + 1))...
                + (zbar3(:, i + 1) - zbar0(:, i + 1))' * (zbar3(:, i + 1) - zbar0(:, i + 1)));
    
    En = En + dt * (sum(abs(rho*C*(zbar1(:, i + 1)-zbar0(:, i + 1))+q1*(zbar1(:, i + 1)-zbar0(:, i + 1)).^a).^p) ...
         + sum(abs(rho*C*(zbar2(:, i + 1)-zbar0(:, i + 1))+q1*(zbar2(:, i + 1)-zbar0(:, i + 1)).^a).^p) ...
         + sum(abs(rho*C*(zbar3(:, i + 1)-zbar0(:, i + 1))+q1*(zbar3(:, i + 1)-zbar0(:, i + 1)).^a).^p));
%     for m = 1 : delta_step+1
    if ebar(i+1)<=1e-7
        TC(k) = dt * i;
        EC(k) = En;
%         Phi(m,k) = delta(m)*TC(k)/TC_max + (1-delta(m))*EC(k)/EC_max;
%         if(abs(Phi(k)-0.0802)<=1e-4)
%             q1
%         end
        break;
    end
%     end
end
end

TC_max = max(TC);
TC_min = min(TC);
EC_max = max(EC);
EC_min = min(EC);

for k = 1 : q1_step+1
    Phi(k) = delta*((TC(k)-TC_min)/(TC_max-TC_min)) + (1-delta)*((EC(k)-EC_min)/(EC_max-EC_min));
end

plot(q1_axis, Phi, '-', 'LineWidth', 2);
xlabel('Control gain q_1');
ylabel('\Phi');
hold on;

% legend('\delta=0.1','\delta=0.2','\delta=0.3','\delta=0.4','\delta=0.5','\delta=0.6','\delta=0.7','\delta=0.8','\delta=0.9')
