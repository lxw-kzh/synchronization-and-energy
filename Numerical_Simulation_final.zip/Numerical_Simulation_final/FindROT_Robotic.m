clear all;
clc;

% outer coupling matrices
B1 = [-3, 1.5, 1.5;
      1, -3, 2;
      3, 1, -4];

B2 = [0, 0, 0;
      0, -3, 3;
      1.5, 0.5, -2];

B3 = [-3.5, 1.5, 2;
      -0.5, 0.5, 0;
      0.5, 3.5, -4];

% inner coupling matrices
C1 = [9, 0;
      0, 9];

C2 = [7, 1;
      1, -0.5];

C3 = [9, 1;
      1, 3];

C = [4, 0.5;
     0.5, 5];

      
B_11 = C1(1,1)*B1 + C2(1,1)*B2 + C3(1,1)*B3;
B_12 = C1(1,2)*B1 + C2(1,2)*B2 + C3(1,2)*B3;
B_21 = C1(2,1)*B1 + C2(2,1)*B2 + C3(2,1)*B3;
B_22 = C1(2,2)*B1 + C2(2,2)*B2 + C3(2,2)*B3;

[eigenVector1, eigenValue1] = eig(B_11');
eigenVec1 = eigenVector1(:, 1);
ome1 = eigenVec1 / sum(eigenVec1);
[eigenVector2, eigenValue2] = eig(B_22');
eigenVec2 = eigenVector2(:, 1);
ome2 = eigenVec2 / sum(eigenVec2);

B_11 = B_11 - diag([C(1,1), C(1,1), C(1,1)]);
B_12 = B_12 - diag([C(1,2), C(1,2), C(1,2)]);
B_21 = B_21 - diag([C(2,1), C(2,1), C(2,1)]);
B_22 = B_22 - diag([C(2,2), C(2,2), C(2,2)]);

I1 = diag(ome1);
I2 = diag(ome2);

Z = zeros(3, 3);
I = [I1, Z;
     Z, I2];

B = [B_11, B_12;
     B_21, B_22];
 
BB = (I*B + B'*I) / 2;

eig(BB);

rho = 0.35;
mu = 0.843;
res1 = mu * 0.4546 + rho * (-1.2522) % for finite-time
