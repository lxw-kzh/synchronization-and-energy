function result = generalized_expint(n, x)
    integrand = @(t) exp(-x * t) ./ t.^n;

    result = integral(integrand, 1, Inf, 'RelTol',1e-10, 'AbsTol',1e-12);
end
