% Parameters
n = 100; % Number of nodes
k = 4;   % Each node is connected to k nearest neighbors
p = 0.1; % Rewiring probability

% Generate small-world network using Watts-Strogatz model
G = WattsStrogatz(n, k, p);

% Extract adjacency matrix
M = full(adjacency(G));

% Plot the network
figure;
h = plot(G, 'Layout', 'circle'); % Circular layout
h.NodeColor = 'k';              % Set node color to black
h.MarkerSize = 5;               % Node size
h.EdgeColor = 'k';              % Set edge color to black
% title('A Small-World Network');
