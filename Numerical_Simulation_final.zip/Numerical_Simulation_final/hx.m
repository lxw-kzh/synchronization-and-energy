function [res] = hx(x)
res = 0.5*(abs(x + 1) - abs(x - 1));
end

