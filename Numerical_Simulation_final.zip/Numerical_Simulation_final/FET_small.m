clear all;
clc;
% 100 nodes

T = 6;
dt = 0.0001;
step = round(T / dt);
N = 100; % number of nodes
W = 1; % number of weights
dm = 1;% dimension
rho = 20;% coupling strength
q1 = 1;
a = 3/5;

z = zeros(N, step);
for i = 1 : N
    z(i, 1) = 0.01*i;
end

z_axis = zeros(1, step);
for i = 2 : step
   z_axis(i) =  dt * (i - 1);
end

% B1 = zeros(N, N);
C1 = ones(1);
C = ones(1);

G = WattsStrogatz(100, 4, 0.1);
B1 = full(adjacency(G));

for i = 1 : N
    B1(i,i) = -sum(B1(i, :));
end

% Plot the network
figure;
h = plot(G, 'Layout', 'circle');
h.NodeColor = 'k';
h.MarkerSize = 5;
h.EdgeColor = 'k'; 

z0 = zeros(1, step);
z0(1) = 0;
ebar = zeros(1, step);
for i = 1 : N
    ebar(1) = ebar(1) + (z(i,1) - z0(1))^2;
end
ebar(1) = sqrt(ebar(1));

V0 = 0;
for i = 1 : N
    V0 = V0 + 1/2*(z(i,1)-z0(1))^2;
end

alpha2 = (q1*2^((a+1)/2))/(1^((a-1)/2));
T_est = 2*V0^((1-a)/2)/(alpha2*(1-a))% estimation of time

p = 2;
Cp = 1;
alpha3 = (2^(3*p/2)*rho^p*Cp^p*(N*dm)^(1-min(p,2)/2))/(alpha2*(p+1-a)*1^(p/2));
alpha4 = (2^(a*p/2+p)*q1^p*(N*dm)^((max(p,2)-a*p)/2))/(alpha2*(a*p+1-a)*1^(a*p/2));
En_est = alpha3*V0^((p+1-a)/2)+alpha4*V0^((a*p+1-a)/2)% estimation of energy

En = 0;% true value

% q1_step = 10;
% q1_axis = 0.5:0.1:1.5;
% TC = zeros(1, q1_step+1);
% EC = zeros(1, q1_step+1);

% for k = 1 : q1_step+1
%     q1 = q1_axis(k);
%     En = 0;
for i = 1 : (step - 1)
    tmp = zeros(dm, N);
    for j = 1 : N
        for k = 1 : N
           tmp(:, j) = tmp(:, j) + rho*B1(j,k)*C1*z(k, i);
        end
        tmp(:, j) = tmp(:, j) - rho*C*(z(1,i)-z0(i)) - q1*(z(1,i)-z0(i))^a;

        z0(i+1) = z0(i) + (z0(i))*dt;
        z(j, i+1) = z(j, i) + ((z(j,i))+tmp(:, j))*dt;
    end

    for k = 1 : N
        ebar(i+1) = ebar(i+1) + (z(k,i+1)-z0(i+1))^2;
        En = En + dt*sum(abs(rho*C*(z(k,i+1)-z0(i + 1))+q1*(z(k,i+1)-z0(i + 1))^a)^p);
    end
    ebar(i+1) = sqrt(ebar(i+1));

    if ebar(i+1)<=1e-7
        dt * i
        En
%         TC(k) = dt * i;
%         EC(k) = En;
        break;
    end
end
% end

figure;
plot(z_axis, ebar, '-', 'LineWidth', 2);
xlabel('Time t');
ylabel('E');
xlim([0, T]);
hold on;
% 
% subplot(2,1,1);
% plot(q1_axis, TC, '-', 'LineWidth', 2);
% xlabel('Control gain q_1');
% ylabel('T');
% title('(a). The trajectory of settling time');
% 
% subplot(2,1,2);
% plot(q1_axis, EC, '-', 'LineWidth', 2, 'Color', 'g');
% xlabel('Control gain q_1');
% ylabel('$$\mathcal{E}$$', 'Interpreter','latex');
% title('(b). The trajectory of energy consumption');
% 


