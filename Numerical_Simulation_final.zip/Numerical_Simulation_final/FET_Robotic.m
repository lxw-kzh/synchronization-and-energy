clear all;
clc;

% outer coupling matrices
B1 = [-3, 1.5, 1.5;
      1, -3, 2;
      3, 1, -4];

B2 = [0, 0, 0;
      0, -3, 3;
      1.5, 0.5, -2];

B3 = [-3.5, 1.5, 2;
      -0.5, 0.5, 0;
      0.5, 3.5, -4];

% inner coupling matrices
C1 = [9, 0;
      0, 9];

C2 = [7, 1;
      1, -0.5];

C3 = [9, 1;
      1, 3];

C = [4, 0.5;
     0.5, 5];


T = 2;
dt = 0.0001;
step = T / dt;
N = 3; % number of nodes
W = 3; % number of weights
dm = 2;% dimension
rho = 0.35;% coupling strength
q1 = 1;
a = 3/5;


z_axis = zeros(1, step);
for i = 2 : step
   z_axis(i) =  dt * (i - 1);
end

z0_1 = [1, 2]';
z0_2 = [2, 3]';
z0_3 = [3, 4]';

zbar1 = zeros(dm, step);% first node
zbar2 = zeros(dm, step);% second node
zbar3 = zeros(dm, step);% third node
zbar1(:, 1) = z0_1;
zbar2(:, 1) = z0_2;
zbar3(:, 1) = z0_3;

% initial values
z0_0 = [1, 1]';
zbar0 = zeros(dm, step);
zbar0(:, 1) = z0_0;

ebar = zeros(1, step);
ebar(1) = sqrt((z0_1 - z0_0)' * (z0_1 - z0_0) + (z0_2 - z0_0)' * (z0_2 - z0_0) + (z0_3 - z0_0)' * (z0_3 - z0_0));

ome1 = [0.2483, 0.4546, 0.2971];
ome2 = [0.2898, 0.4367, 0.2735];  
    
V0 = 1/2*(ome1(1)*(z0_1(1)-z0_0(1))^2+ome2(1)*(z0_1(2)-z0_0(2))^2 ...
     + ome1(2)*(z0_2(1)-z0_0(1))^2+ome2(2)*(z0_2(2)-z0_0(2))^2 ...
     + ome1(3)*(z0_3(1)-z0_0(1))^2+ome2(3)*(z0_3(2)-z0_0(2))^2);

alpha2 = (q1*2^((a+1)/2))/(0.2483^((a-1)/2));
T_est = 2*V0^((1-a)/2)/(alpha2*(1-a))% estimation of time

p = 2;
Cp = 5.2071;
alpha3 = (2^(3*p/2)*rho^p*Cp^p*(N*dm)^(1-min(p,2)/2))/(alpha2*(p+1-a)*0.2483^(p/2));
alpha4 = (2^(a*p/2+p)*q1^p*(N*dm)^((max(p,2)-a*p)/2))/(alpha2*(a*p+1-a)*0.2483^(a*p/2));
En_est = alpha3*V0^((p+1-a)/2)+alpha4*V0^((a*p+1-a)/2)% estimation of energy

En = 0;% true value

q1_step = 20;
q1_axis = 1:0.1:3;
TC = zeros(1, q1_step+1);
EC = zeros(1, q1_step+1);

flag = 0;

for k = 1 : q1_step+1
    q1 = q1_axis(k);
    En = 0;
for i = 1 : (step - 1)
    tmp = zeros(dm, N);
    
    for j = 1 : N
        tmp(:, j) = rho * (B1(j, 1) * C1 * zbar1(:, i)...
                    + B1(j, 2) * C1 * zbar2(:, i) + B1(j, 3) * C1 * zbar3(:, i)...
                    + B2(j, 1) * C2 * zbar1(:, i) + B2(j, 2) * C2 * zbar2(:, i)...
                    + B2(j, 3) * C2 * zbar3(:, i) + B3(j, 1) * C3 * zbar1(:, i)...
                    + B3(j, 2) * C3 * zbar2(:, i) + B3(j, 3) * C3 * zbar3(:, i));
    end
    tmp(:, 1) = tmp(:, 1) - rho * C * (zbar1(:, i)-zbar0(:, i)) - q1 * (zbar1(:, i)-zbar0(:, i)).^a;
    tmp(:, 2) = tmp(:, 2) - rho * C * (zbar2(:, i)-zbar0(:, i)) - q1 * (zbar2(:, i)-zbar0(:, i)).^a;
    tmp(:, 3) = tmp(:, 3) - rho * C * (zbar3(:, i)-zbar0(:, i)) - q1 * (zbar3(:, i)-zbar0(:, i)).^a;
        
    zbar0(:, i + 1) = zbar0(:, i) + gx2(zbar0(:, i)) * dt;
    zbar1(:, i + 1) = zbar1(:, i) + (gx2(zbar1(:, i)) + tmp(:, 1)) * dt;
    zbar2(:, i + 1) = zbar2(:, i) + (gx2(zbar2(:, i)) + tmp(:, 2)) * dt;
    zbar3(:, i + 1) = zbar3(:, i) + (gx2(zbar3(:, i)) + tmp(:, 3)) * dt;
    ebar(i + 1) = sqrt((zbar1(:, i + 1) - zbar0(:, i + 1))' * (zbar1(:, i + 1) - zbar0(:, i + 1))...
                + (zbar2(:, i + 1) - zbar0(:, i + 1))' * (zbar2(:, i + 1) - zbar0(:, i + 1))...
                + (zbar3(:, i + 1) - zbar0(:, i + 1))' * (zbar3(:, i + 1) - zbar0(:, i + 1)));

    En = En + dt * (sum(abs(rho*C*(zbar1(:, i + 1)-zbar0(:, i + 1))+q1*(zbar1(:, i + 1)-zbar0(:, i + 1)).^a).^p) ...
         + sum(abs(rho*C*(zbar2(:, i + 1)-zbar0(:, i + 1))+q1*(zbar2(:, i + 1)-zbar0(:, i + 1)).^a).^p) ...
         + sum(abs(rho*C*(zbar3(:, i + 1)-zbar0(:, i + 1))+q1*(zbar3(:, i + 1)-zbar0(:, i + 1)).^a).^p));

%     if flag == 1
%         continue;
%     end
    if ebar(i+1)<=1e-7
%         flag = 1;
%         dt * i
%         En
        TC(k) = dt * i;
        EC(k) = En;
        break;
    end
end
end
% 
% plot(z_axis, ebar, '-', 'LineWidth', 2);
% xlabel('Time t');
% ylabel('E');
% xlim([0, T]);
% % axes('position',[0.55,0.55,0.3,0.3]);
% % plot(z_axis(1:2000),ebar(1:2000));
% hold on;

subplot(2,1,1);
plot(q1_axis, TC, '-', 'LineWidth', 2);
xlabel('Control gain q_1');
ylabel('T');
title('(a). The trajectory of settling time');

subplot(2,1,2);
plot(q1_axis, EC, '-', 'LineWidth', 2, 'Color', 'g');
xlabel('Control gain q_1');
ylabel('$$\mathcal{E}$$', 'Interpreter','latex');
title('(b). The trajectory of energy consumption');


