clear all;
clc;

N = 100;
C1 = ones(1);
C = ones(1);

G = WattsStrogatz(100, 4, 0.1);
B1 = full(adjacency(G));

for i = 1 : N
    B1(i,i) = -sum(B1(i, :));
end

B_11 = C1(1,1)*B1;

ome1 = null(B_11') / sum(null(B_11'));

B_11 = B_11 - diag(ones(1,N));

I1 = diag(ome1);

I = [I1];

B = [B_11];
 
BB = (I*B + B'*I) / 2;

eig(BB);

rho = 20;
mu = 1;
res1 = mu * max(ome1) + rho * max(eig(BB)) % for finite-time
