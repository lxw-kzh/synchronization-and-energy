function [res] = gx2(x)
res = [x(2), -1/12*(0.2*x(2)+0.8*9.8*sin(x(1)))]';
end

